Pharo 3.0

This distribution was built May 07, 2014.

Please Note:
------------

Pharo does not yet natively run on a 64bits Linux. Just install the ia32/i386 runtime libraries and you should be fine. On Ubuntu and other 
debian-based systems, these libraries are named 'ia32-libs'.

